import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

 
void main() {
  runApp(StudentManagementApp());
}

class StudentManagementApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Student Management System',
      initialRoute: '/splash',  
      routes: {
        '/splash': (context) => SplashScreen(),
        '/': (context) => WelcomeScreen(),
        '/signup': (context) => SignUpScreen(),
        '/login': (context) => LoginPage(),
        '/attendance': (context) => StudentAttendancePage(),
        '/attendance-summary': (context) => AttendanceSummaryPage(),
      },
    );
  }
}


////////////////////////////////////Splash Screen///////////////////////////////////////

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHomeScreen();
  }

  
  Future<void> _navigateToHomeScreen() async {
    await Future.delayed(Duration(seconds: 5));  
    Navigator.pushReplacementNamed(context, '/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              'assets/welcome (2).json',  
              height: 500,
            ),
           
          ],
        ),
      ),
    );
  }
}
/////////////////////////////////////////////////Welcome Screen////////////////////////////////////////////////////////
class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              Text(
                'Welcome',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Welcome to Student Management System',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.blue,
                ),
              ),
              Image.asset(
                'assets/welcome.jpg',  
                height: 200,
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginPage()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  'Login',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SignUpScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(color: Colors.blue),
                  ),
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue,
                ),
                child: Text(
                  'Sign Up',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/////////////////////////////////////////////////////////// Signup Page///////////////////////////////////////////
 

 
Map<String, Map<String, String>> userData = {}; 


 

class SignUpScreen extends StatelessWidget {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  Future<void> saveUserData() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Save user data
    prefs.setString('username', usernameController.text);
    prefs.setString('email', emailController.text);
    prefs.setString('password', passwordController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        title: Center(
          child: Text("SignUp", style: TextStyle(color: Colors.white)),
        ),
      ),
      backgroundColor: Colors.blue,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Create an account',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 20),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: confirmPasswordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Confirm Password',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (passwordController.text == confirmPasswordController.text) {
                  saveUserData();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginPage()),
                  );
                } else {
                  _showErrorDialog(context, 'Passwords do not match!');
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text('Sign Up', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Already have an account? Login', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}



//////////////////////////////////////////////////////////// Login Page/////////////////////////////////////////////
 

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  Future<void> checkLogin() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String? storedEmail = prefs.getString('email');
    String? storedPassword = prefs.getString('password');

    if (storedEmail != null && storedPassword != null) {
      if (emailController.text == storedEmail && passwordController.text == storedPassword) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StudentAttendancePage()),
        );
      } else {
        _showErrorDialog(context, 'Invalid email or password!');
      }
    } else {
      _showErrorDialog(context, 'No user found. Please sign up.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        title: Center(
          child: Text("Login", style: TextStyle(color: Colors.white)),
        ),
      ),
      backgroundColor: Colors.blue,
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Login to your account',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 20),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: checkLogin,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text('Sign In', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            SizedBox(height: 10),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SignUpScreen()),
                );
              },
              child: Text('If you have not an account? Signup', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }
}

 
Map<String, bool> studentAttendance = {};

//////////////////////////////////////////////////////////// Attendance Page///////////////////////////////////////////////
class StudentAttendancePage extends StatefulWidget {
  @override
  _StudentAttendancePageState createState() => _StudentAttendancePageState();
}

class _StudentAttendancePageState extends State<StudentAttendancePage> {
  List<Map<String, dynamic>> students = [];
  String filePath = 'assets/students.xlsx'; // Excel file path in assets
  String selectedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    requestStoragePermission();
    loadExcelFile();
  }
 
  Future<void> requestStoragePermission() async {
    var status = await Permission.storage.request();
    var manageStatus = await Permission.manageExternalStorage.request();
    if (status.isGranted && manageStatus.isGranted) {
      print('Permissions granted');
    } else {
      print('Permissions denied');
    }
  }
 
  Future<void> loadExcelFile() async {
    try {
      final ByteData data = await rootBundle.load(filePath);
      final bytes = data.buffer.asUint8List();
      var excel = Excel.decodeBytes(bytes);

      setState(() {
        students.clear();
        for (var table in excel.tables.keys) {
          var rows = excel.tables[table]?.rows;
          if (rows != null) {
            for (var row in rows) {
              if (row[0] != null && row[1] != null) {
                students.add({
                  'id': row[0]?.value?.toString(),
                  'name': row[1]?.value?.toString(),
                  'present': false,
                });
                studentAttendance[(row[1]?.value?.toString() ?? '')] = false;
              }
            }
          }
        }
      });
    } catch (e) {
      print('Error loading Excel file: $e');
    }
  }

   
  void saveAttendance() {
     
    print("Attendance for $selectedDate:");
    studentAttendance.forEach((student, isPresent) {
      print('$student: ${isPresent ? 'Present' : 'Absent'}');
    });
  }

 
  void submitAttendance(BuildContext context) {
    saveAttendance();  

 
    showDialog(
      
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.blue,
          title: Text('Attendance Submitted',style: TextStyle(color: Colors.white),),
          content: Text('The attendance for $selectedDate has been successfully submitted.',style: TextStyle(color: Colors.white),),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);   
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme:IconThemeData(color: Colors.white),
        backgroundColor: Colors.blue,
        title: Center(
          child: Text('Attendance System', style: TextStyle(color: Colors.white),),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_vert),
            onPressed: () {
             
              setState(() {
                selectedDate = DateFormat('yyyy-MM-dd').format(DateTime.now());
              });
            },
          ),
        ],
      ),
      drawer: Drawer(
  child: ListView(
    padding: EdgeInsets.zero,
    children: [
      DrawerHeader(
        decoration: BoxDecoration(
          color: Colors.blue,
        ),
        child: Row(
          children: [
            Icon(
              Icons.school, // You can change this to any icon you want
              color: Colors.white,
              size: 30,
            ),
            SizedBox(width: 10),
            Text(
              'Student Management',
              style: TextStyle(color: Colors.white, fontSize: 20),
            ),
          ],
        ),
      ),
  
      ListTile(
        leading: Icon(Icons.manage_accounts),
        title: Text('User Management'),
        onTap: () {
          Navigator.pushNamed(context, '/');
        },
      ),
      ListTile(
        
        leading: Icon(Icons.collections_bookmark),
        title: Text('Attendance'),
        onTap: () {
          Navigator.pushNamed(context, '/attendance');
        },
      ),
      ListTile(
        leading: Icon(Icons.summarize_rounded),
        title: Text('Attendance Summary'),
        onTap: () {
          Navigator.pushNamed(context, '/attendance-summary');
        },
      ),
    ],
  ),
),

      body: Padding(
        
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Attendance for: $selectedDate',style: TextStyle(color: Colors.blue),),
            Expanded(
              child: ListView.builder(
                itemCount: students.length,
                itemBuilder: (context, index) {
                  var student = students[index];
                  return CheckboxListTile(
                    activeColor: Colors.green,
                    title: Text(student['name']),
                    value: studentAttendance[student['name']],
                    onChanged: (bool? value) {
                      setState(() {
                        studentAttendance[student['name']] = value ?? false;
                      });
                    },
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: () {
                submitAttendance(context);
              },
              style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all(Colors.blue), // Set the background color
  ),
              child: Text('Submit Attendance',style: TextStyle(color: Colors.white),),
            ),
          ],
        ),
      ),
    );
  }
}

////////////////////////////////////// Attendance Summary Page////////////////////////////////////////  
class AttendanceSummaryPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
         backgroundColor: Colors.blue,
        title: Center(
          child: Text('Attendance Summary',style: TextStyle(color: Colors.white),)
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Attendance for: ${DateFormat('yyyy-MM-dd').format(DateTime.now())}',style: TextStyle(color: Colors.blue),),
            Expanded(
              child: ListView.builder(
                itemCount: studentAttendance.length,
                itemBuilder: (context, index) {
                  String studentName = studentAttendance.keys.elementAt(index);
                  bool isPresent = studentAttendance[studentName]!;

                  return ListTile(
                    title: Text(studentName),
                    trailing: Text(isPresent ? 'Present' : 'Absent',style: TextStyle(
                        color: isPresent ? Colors.green : Colors.red,  
                      ),),
                    
                  );
                },
              ),
            ),
            
            ElevatedButton(
              
              onPressed: () {
                Navigator.pop(context);
                
              },
               style: ButtonStyle(
    backgroundColor: MaterialStateProperty.all(Colors.blue),  
  ),
              child: Text('Back to Attendance',style: TextStyle(color: Colors.white),),
            ),
          ],
        ),
      ),
    );
  }
}  